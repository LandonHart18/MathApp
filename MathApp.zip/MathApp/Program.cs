﻿using System;

namespace MathApp
{
	public class Program
	{
		static void Main()
		{
			MathCalculator mc = new MathCalculator();
			mc.Menu();
		}
	}
}
